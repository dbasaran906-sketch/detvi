package com.detvi.remote.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import android.widget.Toast
import com.detvi.remote.R
import com.detvi.remote.data.TvStore
import com.detvi.remote.tv.Certs
import com.detvi.remote.tv.Keys
import com.detvi.remote.tv.RemoteConnection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Ana ekran widget'ı: aç/kapat, ses kıs, sessiz, ses aç. Son kullanılan TV'ye gider. */
class RemoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, buildViews(context))
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACTION_KEY) return
        val code = intent.getIntExtra(EXTRA_KEY, -1)
        if (code < 0) return

        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val tv = TvStore(app).lastTv()
                if (tv == null) {
                    toast(app, "Önce DETVI uygulamasından bir TV bağla")
                } else {
                    val ok = RemoteConnection.oneShot(Certs.load(app), tv.host, code)
                    if (!ok) toast(app, "TV'ye ulaşılamadı")
                }
            } catch (e: Exception) {
                toast(app, "Bir hata oluştu")
            } finally {
                pending.finish()
            }
        }
    }

    private fun toast(context: Context, text: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildViews(context: Context): RemoteViews {
        val v = RemoteViews(context.packageName, R.layout.widget_remote)
        v.setOnClickPendingIntent(R.id.w_power, keyIntent(context, Keys.POWER))
        v.setOnClickPendingIntent(R.id.w_vol_down, keyIntent(context, Keys.VOL_DOWN))
        v.setOnClickPendingIntent(R.id.w_mute, keyIntent(context, Keys.MUTE))
        v.setOnClickPendingIntent(R.id.w_vol_up, keyIntent(context, Keys.VOL_UP))
        return v
    }

    private fun keyIntent(context: Context, code: Int): PendingIntent {
        val intent = Intent(context, RemoteWidgetProvider::class.java)
            .setAction(ACTION_KEY)
            .putExtra(EXTRA_KEY, code)
        return PendingIntent.getBroadcast(
            context,
            code,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {
        const val ACTION_KEY = "com.detvi.remote.WIDGET_KEY"
        const val EXTRA_KEY = "key"
    }
}
