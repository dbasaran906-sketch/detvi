package com.detvi.remote.tv

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream

/** Çok küçük bir protobuf yazıcı (sadece ihtiyacımız olan alan tipleri). */
class ProtoWriter {
    private val out = ByteArrayOutputStream()

    private fun rawVarint(value: Long) {
        var x = value
        while (true) {
            if ((x and 0x7FL.inv()) == 0L) {
                out.write(x.toInt())
                return
            }
            out.write(((x and 0x7FL) or 0x80L).toInt())
            x = x ushr 7
        }
    }

    fun int(field: Int, value: Int): ProtoWriter {
        rawVarint(((field shl 3) or 0).toLong())
        rawVarint(value.toLong())
        return this
    }

    fun bytes(field: Int, value: ByteArray): ProtoWriter {
        rawVarint(((field shl 3) or 2).toLong())
        rawVarint(value.size.toLong())
        out.write(value)
        return this
    }

    fun string(field: Int, value: String): ProtoWriter = bytes(field, value.toByteArray(Charsets.UTF_8))

    fun message(field: Int, block: ProtoWriter.() -> Unit): ProtoWriter {
        val inner = ProtoWriter()
        inner.block()
        return bytes(field, inner.toByteArray())
    }

    fun toByteArray(): ByteArray = out.toByteArray()
}

class ProtoField(val number: Int, val varint: Long, val data: ByteArray?) {
    fun string(): String = data?.toString(Charsets.UTF_8) ?: ""
    fun sub(): List<ProtoField> = if (data == null) emptyList() else Proto.parse(data)
}

fun List<ProtoField>.field(number: Int): ProtoField? = firstOrNull { it.number == number }

object Proto {
    fun parse(bytes: ByteArray): List<ProtoField> {
        val list = ArrayList<ProtoField>()
        var i = 0

        fun readVarint(): Long {
            var shift = 0
            var result = 0L
            while (true) {
                val b = bytes[i++].toInt()
                result = result or ((b and 0x7F).toLong() shl shift)
                if ((b and 0x80) == 0) break
                shift += 7
            }
            return result
        }

        try {
            while (i < bytes.size) {
                val tag = readVarint().toInt()
                val number = tag ushr 3
                when (tag and 7) {
                    0 -> list.add(ProtoField(number, readVarint(), null))
                    1 -> i += 8
                    2 -> {
                        val len = readVarint().toInt()
                        list.add(ProtoField(number, 0, bytes.copyOfRange(i, i + len)))
                        i += len
                    }
                    5 -> i += 4
                    else -> return list
                }
            }
        } catch (e: Exception) {
            // Eksik/bozuk veri: elde ne varsa onu döndür.
        }
        return list
    }

    /** Uzunluk (varint) önekli mesaj yazar. */
    fun writeFrame(out: OutputStream, msg: ByteArray) {
        val w = ByteArrayOutputStream()
        var len = msg.size
        while (len >= 0x80) {
            w.write((len and 0x7F) or 0x80)
            len = len ushr 7
        }
        w.write(len)
        w.write(msg)
        out.write(w.toByteArray())
        out.flush()
    }

    /** Uzunluk (varint) önekli mesaj okur. Bağlantı kapandıysa null döner. */
    fun readFrame(input: InputStream): ByteArray? {
        var len = 0
        var shift = 0
        while (true) {
            val b = input.read()
            if (b < 0) return null
            len = len or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
            if (shift > 28) return null
        }
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val n = input.read(buf, off, len - off)
            if (n < 0) return null
            off += n
        }
        return buf
    }
}
