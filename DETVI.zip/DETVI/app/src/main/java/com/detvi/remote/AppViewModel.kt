package com.detvi.remote

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.detvi.remote.data.SavedTv
import com.detvi.remote.data.TvStore
import com.detvi.remote.tv.Certs
import com.detvi.remote.tv.Discovery
import com.detvi.remote.tv.FoundTv
import com.detvi.remote.tv.LinkState
import com.detvi.remote.tv.LinkStatus
import com.detvi.remote.tv.PairingSession
import com.detvi.remote.tv.RemoteConnection
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class Screen { Home, Remote }

enum class PairStage { Connecting, AskCode, Verifying, Error }

data class PairUi(
    val host: String,
    val name: String,
    val stage: PairStage,
    val error: String = "",
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = TvStore(app)
    private val identity: Deferred<Certs.Identity> = viewModelScope.async(Dispatchers.IO) { Certs.load(app) }

    private val _saved = MutableStateFlow(store.load())
    val saved: StateFlow<List<SavedTv>> = _saved

    private val _found = MutableStateFlow<List<FoundTv>>(emptyList())
    val found: StateFlow<List<FoundTv>> = _found

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning

    private val _screen = MutableStateFlow(Screen.Home)
    val screen: StateFlow<Screen> = _screen

    private val _pairing = MutableStateFlow<PairUi?>(null)
    val pairing: StateFlow<PairUi?> = _pairing

    private val _link = MutableStateFlow(LinkState())
    val link: StateFlow<LinkState> = _link

    private val _current = MutableStateFlow<SavedTv?>(null)
    val current: StateFlow<SavedTv?> = _current

    private var conn: RemoteConnection? = null
    private var linkJob: Job? = null
    private var session: PairingSession? = null
    private var scanJob: Job? = null

    private val discovery = Discovery(app) { tv -> addFound(tv) }

    @Synchronized
    private fun addFound(tv: FoundTv) {
        val list = _found.value.toMutableList()
        val sameHost = list.indexOfFirst { it.host == tv.host }
        if (sameHost >= 0) {
            // mDNS adı, taramadan gelen genel addan daha iyi
            if (list[sameHost].name == "Android TV" && tv.name != "Android TV") list[sameHost] = tv
        } else {
            list.add(tv)
        }
        _found.value = list

        // Kayıtlı TV'nin IP'si değiştiyse güncelle
        val s = _saved.value.firstOrNull { it.name == tv.name && it.host != tv.host }
        if (s != null) _saved.value = store.updateHost(s.name, tv.host)
    }

    // ---------- Bulma ----------

    fun startDiscovery() {
        scanJob?.cancel()
        _found.value = emptyList()
        _scanning.value = true
        discovery.start()
        scanJob = viewModelScope.launch {
            delay(3500)
            if (_found.value.isEmpty()) {
                discovery.scanSubnet().forEach { addFound(it) }
            }
            delay(800)
            _scanning.value = false
        }
    }

    fun deepScan() {
        scanJob?.cancel()
        _scanning.value = true
        scanJob = viewModelScope.launch {
            discovery.scanSubnet().forEach { addFound(it) }
            _scanning.value = false
        }
    }

    fun stopDiscovery() {
        discovery.stop()
    }

    // ---------- Seçim / bağlanma ----------

    fun onFoundTapped(tv: FoundTv) {
        val s = _saved.value.firstOrNull { it.host == tv.host } ?: _saved.value.firstOrNull { it.name == tv.name }
        if (s != null) connect(s.copy(host = tv.host)) else beginPairing(tv.host, tv.name)
    }

    fun addManual(host: String) {
        val h = host.trim()
        if (h.isEmpty()) return
        val s = _saved.value.firstOrNull { it.host == h }
        if (s != null) connect(s) else beginPairing(h, "Android TV")
    }

    fun connect(tv: SavedTv) {
        _current.value = tv
        _screen.value = Screen.Remote
        openConnection(tv.host)
    }

    private fun openConnection(host: String) {
        viewModelScope.launch {
            val id = identity.await()
            linkJob?.cancel()
            conn?.disconnect()
            val c = RemoteConnection(id, viewModelScope)
            conn = c
            linkJob = launch {
                c.state.collect { st ->
                    _link.value = st
                    if (st.status == LinkStatus.Ready) {
                        _current.value?.let { _saved.value = store.touch(it.host) }
                    }
                }
            }
            c.connect(host)
        }
    }

    fun reconnect() {
        _current.value?.let { openConnection(it.host) }
    }

    fun rePair() {
        val tv = _current.value ?: return
        beginPairing(tv.host, tv.name)
    }

    fun leaveRemote() {
        linkJob?.cancel()
        conn?.disconnect()
        conn = null
        _link.value = LinkState()
        _current.value = null
        _screen.value = Screen.Home
    }

    // ---------- Eşleştirme ----------

    fun beginPairing(host: String, name: String) {
        session?.close()
        _pairing.value = PairUi(host, name, PairStage.Connecting)
        viewModelScope.launch {
            try {
                val s = PairingSession(identity.await())
                session = s
                s.start(host)
                val shownName = s.serverName.ifBlank { name }
                _pairing.value = PairUi(host, shownName, PairStage.AskCode)
            } catch (e: Exception) {
                _pairing.value = PairUi(host, name, PairStage.Error, "TV'ye bağlanılamadı. TV açık ve aynı Wi-Fi'de mi?")
            }
        }
    }

    fun submitCode(code: String) {
        val p = _pairing.value ?: return
        val s = session ?: return
        _pairing.value = p.copy(stage = PairStage.Verifying)
        viewModelScope.launch {
            try {
                s.finish(code)
                val tv = SavedTv(p.name, p.host, System.currentTimeMillis())
                _saved.value = store.upsert(tv)
                _pairing.value = null
                session = null
                connect(tv)
            } catch (e: Exception) {
                _pairing.value = p.copy(stage = PairStage.Error, error = e.message ?: "Eşleştirme başarısız")
            }
        }
    }

    fun cancelPairing() {
        session?.close()
        session = null
        _pairing.value = null
    }

    fun retryPairing() {
        val p = _pairing.value ?: return
        beginPairing(p.host, p.name)
    }

    fun removeSaved(tv: SavedTv) {
        _saved.value = store.remove(tv.host)
    }

    // ---------- Kumanda ----------

    fun key(code: Int) {
        conn?.key(code)
    }

    fun openLink(link: String) {
        conn?.openLink(link)
    }

    fun typeText(text: String) {
        conn?.typeText(text)
    }

    override fun onCleared() {
        discovery.stop()
        session?.close()
        conn?.disconnect()
        super.onCleared()
    }
}
