package com.detvi.remote.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Dv {
    val Black = Color(0xFF000000)
    val Ink = Color(0xFF0A0A0C)
    val Card = Color(0xFF141417)
    val CardHi = Color(0xFF1D1D22)
    val Line = Color(0xFF2A2A30)
    val Red = Color(0xFFFF2A1F)
    val RedDeep = Color(0xFFB3150D)
    val Green = Color(0xFF12C25E)
    val Blue = Color(0xFF2F6BFF)
    val Yellow = Color(0xFFFFB800)
    val White = Color(0xFFFFFFFF)
    val Muted = Color(0xFF8C8C96)
}

private val scheme = darkColorScheme(
    primary = Dv.Red,
    onPrimary = Dv.White,
    secondary = Dv.Green,
    onSecondary = Dv.Black,
    background = Dv.Black,
    onBackground = Dv.White,
    surface = Dv.Card,
    onSurface = Dv.White,
    surfaceVariant = Dv.CardHi,
    onSurfaceVariant = Dv.Muted,
    outline = Dv.Line,
)

@Composable
fun DetviTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
