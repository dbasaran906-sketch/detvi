package com.detvi.remote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.detvi.remote.ui.DetviTheme
import com.detvi.remote.ui.Dv
import com.detvi.remote.ui.HomeScreen
import com.detvi.remote.ui.PairDialog
import com.detvi.remote.ui.RemoteScreen
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            DetviTheme {
                App()
            }
        }
    }
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    var splash by rememberSaveable { mutableStateOf(true) }
    val screen by vm.screen.collectAsState()
    val pairing by vm.pairing.collectAsState()

    LaunchedEffect(Unit) {
        delay(1700)
        splash = false
    }
    LaunchedEffect(screen) {
        if (screen == Screen.Home) vm.startDiscovery() else vm.stopDiscovery()
    }
    DisposableEffect(Unit) {
        onDispose { vm.stopDiscovery() }
    }
    BackHandler(enabled = screen == Screen.Remote) { vm.leaveRemote() }

    val target = when {
        splash -> 0
        screen == Screen.Home -> 1
        else -> 2
    }

    Box(Modifier.fillMaxSize().background(Dv.Black)) {
        Crossfade(targetState = target, animationSpec = tween(350), label = "root") { t ->
            when (t) {
                0 -> Splash()
                1 -> HomeScreen(vm)
                else -> RemoteScreen(vm)
            }
        }
        pairing?.let { p ->
            PairDialog(
                p = p,
                onSubmit = { vm.submitCode(it) },
                onRetry = { vm.retryPairing() },
                onCancel = { vm.cancelPairing() },
            )
        }
    }
}

@Composable
private fun Splash() {
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    val pulse by rememberInfiniteTransition(label = "glow").animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glowAlpha",
    )

    Box(Modifier.fillMaxSize().background(Dv.Black), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(360.dp)
                .background(
                    Brush.radialGradient(listOf(Dv.Red.copy(alpha = 0.22f * pulse), Color.Transparent)),
                    CircleShape,
                )
        )
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                alpha = appear.value
                scaleX = 0.88f + 0.12f * appear.value
                scaleY = 0.88f + 0.12f * appear.value
            },
        ) {
            Image(
                painterResource(R.drawable.detvi_logo),
                contentDescription = "DETVI",
                modifier = Modifier.width(290.dp),
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "KUMANDA",
                color = Dv.Muted,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 9.sp,
            )
        }
    }
}
