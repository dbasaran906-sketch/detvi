package com.detvi.remote.tv

import android.content.Context
import android.net.ConnectivityManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket

data class FoundTv(val name: String, val host: String)

/**
 * Aynı Wi-Fi'deki Android TV / Google TV cihazlarını bulur:
 * 1) mDNS (_androidtvremote2._tcp)  2) yedek olarak alt ağda 6466 portu taraması.
 */
class Discovery(private val context: Context, private val onFound: (FoundTv) -> Unit) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var listener: NsdManager.DiscoveryListener? = null
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private val lock = Any()

    fun start() {
        stop()
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                synchronized(lock) { queue.addLast(serviceInfo) }
                resolveNext()
            }
        }
        listener = l
        try {
            nsd.discoverServices("_androidtvremote2._tcp", NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) {
            listener = null
        }
    }

    fun stop() {
        val l = listener ?: return
        listener = null
        try { nsd.stopServiceDiscovery(l) } catch (e: Exception) {}
        synchronized(lock) {
            queue.clear()
            resolving = false
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveNext() {
        val next: NsdServiceInfo = synchronized(lock) {
            if (resolving || queue.isEmpty()) {
                null
            } else {
                resolving = true
                queue.removeFirst()
            }
        } ?: return
        try {
            nsd.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                    synchronized(lock) { resolving = false }
                    resolveNext()
                }

                override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                    val addr = serviceInfo.host
                    if (addr is Inet4Address) {
                        val host = addr.hostAddress
                        if (host != null) onFound(FoundTv(serviceInfo.serviceName ?: "Android TV", host))
                    }
                    synchronized(lock) { resolving = false }
                    resolveNext()
                }
            })
        } catch (e: Exception) {
            synchronized(lock) { resolving = false }
        }
    }

    /** Yedek yöntem: telefonun IP aralığındaki 6466 portunu tarar. */
    suspend fun scanSubnet(): List<FoundTv> = withContext(Dispatchers.IO) {
        val prefix = localPrefix() ?: return@withContext emptyList()
        val gate = Semaphore(48)
        coroutineScope {
            (1..254).map { i ->
                async {
                    gate.withPermit {
                        val ip = "$prefix$i"
                        if (isOpen(ip, 6466)) FoundTv("Android TV", ip) else null
                    }
                }
            }.awaitAll().filterNotNull()
        }
    }

    private fun isOpen(ip: String, port: Int): Boolean =
        try {
            Socket().use { it.connect(InetSocketAddress(ip, port), 400); true }
        } catch (e: Exception) {
            false
        }

    private fun localPrefix(): String? {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val lp = cm.getLinkProperties(cm.activeNetwork) ?: return null
            val ip = lp.linkAddresses.firstOrNull { it.address is Inet4Address }?.address?.hostAddress ?: return null
            ip.substringBeforeLast('.') + "."
        } catch (e: Exception) {
            null
        }
    }
}
