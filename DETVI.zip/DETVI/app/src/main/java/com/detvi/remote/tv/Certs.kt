package com.detvi.remote.tv

import android.annotation.SuppressLint
import android.content.Context
import android.util.Base64
import java.io.ByteArrayInputStream
import java.net.InetSocketAddress
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Android TV, kumandayı tanımak için istemci sertifikası ister. Bu sertifikayı
 * ilk açılışta bir kere üretip cihazda saklıyoruz; TV ile eşleşme bu sertifikaya bağlı.
 */
object Certs {
    class Identity(val privateKey: PrivateKey, val cert: X509Certificate)

    private const val PASSWORD = "detvi"

    fun load(context: Context): Identity {
        val prefs = context.getSharedPreferences("detvi_identity", Context.MODE_PRIVATE)
        val k = prefs.getString("key", null)
        val c = prefs.getString("cert", null)
        if (k != null && c != null) {
            try {
                val pk = KeyFactory.getInstance("RSA")
                    .generatePrivate(PKCS8EncodedKeySpec(Base64.decode(k, Base64.NO_WRAP)))
                val cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(ByteArrayInputStream(Base64.decode(c, Base64.NO_WRAP))) as X509Certificate
                return Identity(pk, cert)
            } catch (e: Exception) {
                // bozuk kayıt: yeniden üret
            }
        }
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val kp = kpg.generateKeyPair()
        val cert = selfSigned(kp.public.encoded, kp.private)
        prefs.edit()
            .putString("key", Base64.encodeToString(kp.private.encoded, Base64.NO_WRAP))
            .putString("cert", Base64.encodeToString(cert.encoded, Base64.NO_WRAP))
            .apply()
        return Identity(kp.private, cert)
    }

    // ---- Elle DER ile kendinden imzalı sertifika (ek kütüphane gerekmez) ----

    private fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    private fun der(tag: Int, content: ByteArray): ByteArray {
        val len = content.size
        val lenBytes = when {
            len < 0x80 -> byteArrayOf(len.toByte())
            len < 0x100 -> byteArrayOf(0x81.toByte(), len.toByte())
            else -> byteArrayOf(0x82.toByte(), (len shr 8).toByte(), len.toByte())
        }
        return byteArrayOf(tag.toByte()) + lenBytes + content
    }

    private fun selfSigned(spki: ByteArray, privateKey: PrivateKey): X509Certificate {
        val sigAlg = der(0x30, hex("06092A864886F70D01010B") + hex("0500")) // sha256WithRSAEncryption
        val name = der(0x30, der(0x31, der(0x30, hex("0603550403") + der(0x0C, "DETVI".toByteArray()))))
        val serialBytes = ByteArray(8)
        SecureRandom().nextBytes(serialBytes)
        serialBytes[0] = ((serialBytes[0].toInt() and 0x7F) or 0x01).toByte()
        val serial = der(0x02, serialBytes)

        val fmt = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val now = System.currentTimeMillis()
        val notBefore = fmt.format(Date(now - 86_400_000L))
        val notAfter = fmt.format(Date(now + 3650L * 86_400_000L))
        val validity = der(0x30, der(0x17, notBefore.toByteArray()) + der(0x17, notAfter.toByteArray()))

        val tbs = der(0x30, hex("A003020102") + serial + sigAlg + name + validity + name + spki)
        val sig = Signature.getInstance("SHA256withRSA").run {
            initSign(privateKey)
            update(tbs)
            sign()
        }
        val certDer = der(0x30, tbs + sigAlg + der(0x03, byteArrayOf(0) + sig))
        return CertificateFactory.getInstance("X.509")
            .generateCertificate(ByteArrayInputStream(certDer)) as X509Certificate
    }

    // ---- TLS ----

    @SuppressLint("TrustAllX509TrustManager", "CustomX509TrustManager")
    private fun sslContext(identity: Identity): SSLContext {
        val ks = KeyStore.getInstance(KeyStore.getDefaultType())
        ks.load(null, null)
        ks.setKeyEntry("detvi", identity.privateKey, PASSWORD.toCharArray(), arrayOf<Certificate>(identity.cert))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, PASSWORD.toCharArray())
        // TV'nin sertifikası kendinden imzalı; eşleştirme kodu zaten karşılıklı doğrulama sağlıyor.
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(kmf.keyManagers, arrayOf<TrustManager>(trustAll), SecureRandom())
        return ctx
    }

    fun connect(identity: Identity, host: String, port: Int, soTimeoutMs: Int): SSLSocket {
        val socket = sslContext(identity).socketFactory.createSocket() as SSLSocket
        try {
            socket.connect(InetSocketAddress(host, port), 5000)
            socket.soTimeout = soTimeoutMs
            socket.startHandshake()
        } catch (e: Exception) {
            try { socket.close() } catch (ignored: Exception) {}
            throw e
        }
        return socket
    }
}
