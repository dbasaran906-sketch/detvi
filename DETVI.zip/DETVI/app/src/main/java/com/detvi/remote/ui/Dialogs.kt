package com.detvi.remote.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.detvi.remote.PairStage
import com.detvi.remote.PairUi
import com.detvi.remote.tv.Keys

private val dialogShape = RoundedCornerShape(28.dp)

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Dv.Red,
    unfocusedBorderColor = Dv.Line,
    cursorColor = Dv.Red,
    focusedTextColor = Dv.White,
    unfocusedTextColor = Dv.White,
)

@Composable
private fun RedButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = Dv.Red,
            contentColor = Dv.White,
            disabledContainerColor = Dv.Line,
            disabledContentColor = Dv.Muted,
        ),
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
fun PairDialog(
    p: PairUi,
    onSubmit: (String) -> Unit,
    onRetry: () -> Unit,
    onCancel: () -> Unit,
) {
    var code by remember(p.stage) { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = Dv.Card,
        shape = dialogShape,
        title = { Text("TV'yi eşleştir", color = Dv.White, fontWeight = FontWeight.Black) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                when (p.stage) {
                    PairStage.Connecting, PairStage.Verifying -> {
                        CircularProgressIndicator(color = Dv.Red, strokeWidth = 3.dp, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.height(14.dp))
                        Text(
                            if (p.stage == PairStage.Connecting) "${p.name} cihazına bağlanılıyor…" else "Kod doğrulanıyor…",
                            color = Dv.Muted,
                            textAlign = TextAlign.Center,
                        )
                    }
                    PairStage.AskCode -> {
                        Text(
                            "${p.name} ekranında beliren 6 haneli kodu gir.",
                            color = Dv.Muted,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        OutlinedTextField(
                            value = code,
                            onValueChange = { v ->
                                code = v.uppercase().filter { it in '0'..'9' || it in 'A'..'F' }.take(6)
                            },
                            singleLine = true,
                            textStyle = TextStyle(
                                fontSize = 28.sp,
                                letterSpacing = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center,
                            ),
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Characters,
                                keyboardType = KeyboardType.Ascii,
                            ),
                            colors = fieldColors(),
                            modifier = Modifier.focusRequester(focus),
                        )
                        LaunchedEffect(Unit) { focus.requestFocus() }
                    }
                    PairStage.Error -> {
                        Text(p.error, color = Dv.Red, textAlign = TextAlign.Center)
                    }
                }
            }
        },
        confirmButton = {
            when (p.stage) {
                PairStage.AskCode -> RedButton("Eşleştir", enabled = code.length == 6) { onSubmit(code) }
                PairStage.Error -> RedButton("Tekrar dene", onClick = onRetry)
                else -> {}
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text("Vazgeç", color = Dv.Muted) }
        },
    )
}

@Composable
fun AddIpDialog(onAdd: (String) -> Unit, onClose: () -> Unit) {
    var ip by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Dv.Card,
        shape = dialogShape,
        title = { Text("IP ile TV ekle", color = Dv.White, fontWeight = FontWeight.Black) },
        text = {
            Column {
                Text(
                    "TV'nin ağ ayarlarındaki IP adresini yaz (örn. 192.168.1.25).",
                    color = Dv.Muted,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = ip,
                    onValueChange = { v -> ip = v.filter { it.isDigit() || it == '.' }.take(15) },
                    singleLine = true,
                    placeholder = { Text("192.168.1.25", color = Dv.Muted) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = fieldColors(),
                )
            }
        },
        confirmButton = { RedButton("Ekle", enabled = ip.count { it == '.' } == 3) { onAdd(ip) } },
        dismissButton = { TextButton(onClick = onClose) { Text("Vazgeç", color = Dv.Muted) } },
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Dv.Card,
        shape = dialogShape,
        title = { Text(title, color = Dv.White, fontWeight = FontWeight.Black) },
        text = { Text(text, color = Dv.Muted) },
        confirmButton = { RedButton(confirm, onClick = onConfirm) },
        dismissButton = { TextButton(onClick = onClose) { Text("Vazgeç", color = Dv.Muted) } },
    )
}

/** Telefon klavyesiyle yazdıkça TV'ye tuş gönderir. */
@Composable
fun KeyboardDialog(onType: (String) -> Unit, onKey: (Int) -> Unit, onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Dv.Card,
        shape = dialogShape,
        title = { Text("TV'ye yaz", color = Dv.White, fontWeight = FontWeight.Black) },
        text = {
            Column {
                Text(
                    "Önce TV'de arama kutusunu aç, sonra buraya yaz.",
                    color = Dv.Muted,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { new ->
                        if (new.length > text.length && new.startsWith(text)) {
                            onType(new.substring(text.length))
                        } else if (new.length < text.length && text.startsWith(new)) {
                            repeat(text.length - new.length) { onKey(Keys.DEL) }
                        } else {
                            repeat(text.length) { onKey(Keys.DEL) }
                            onType(new)
                        }
                        text = new
                    },
                    singleLine = true,
                    colors = fieldColors(),
                    modifier = Modifier.focusRequester(focus),
                )
                LaunchedEffect(Unit) { focus.requestFocus() }
            }
        },
        confirmButton = { RedButton("Ara / Enter") { onKey(Keys.ENTER) } },
        dismissButton = { TextButton(onClick = onClose) { Text("Kapat", color = Dv.Muted) } },
    )
}

@Composable
fun VoiceDialog(text: String, onTv: () -> Unit, onYoutube: () -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Dv.Card,
        shape = dialogShape,
        title = { Text("Sesli komut", color = Dv.White, fontWeight = FontWeight.Black) },
        text = {
            Column {
                Text("\"$text\"", color = Dv.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text(
                    "TV'de YouTube'da aratabilir ya da TV'deki açık arama kutusuna yazdırabilirsin.",
                    color = Dv.Muted,
                    fontSize = 13.sp,
                )
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onTv) { Text("TV'ye yaz", color = Dv.White) }
                RedButton("YouTube'da ara", onClick = onYoutube)
            }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("İptal", color = Dv.Muted) } },
    )
}
