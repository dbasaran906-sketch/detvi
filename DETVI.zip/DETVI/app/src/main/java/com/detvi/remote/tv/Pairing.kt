package com.detvi.remote.tv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import javax.net.ssl.SSLSocket

/**
 * Android TV Remote v2 eşleştirme (port 6467).
 * Akış: istek -> seçenekler -> yapılandırma -> TV'de 6 haneli kod görünür -> kod girilir -> gizli değer gönderilir.
 */
class PairingSession(private val identity: Certs.Identity) {
    private var socket: SSLSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var serverCert: X509Certificate? = null

    var serverName: String = ""
        private set

    private fun msg(field: Int, block: ProtoWriter.() -> Unit): ByteArray =
        ProtoWriter().int(1, 2).int(2, 200).message(field, block).toByteArray()

    private fun send(bytes: ByteArray) = Proto.writeFrame(output!!, bytes)

    private fun readOk(): List<ProtoField> {
        val frame = Proto.readFrame(input!!) ?: throw IOException("TV bağlantıyı kapattı")
        val fields = Proto.parse(frame)
        val status = fields.field(2)?.varint ?: 0L
        if (status != 200L) throw IOException("TV isteği reddetti (kod $status)")
        return fields
    }

    /** TV'ye bağlanır ve ekranda kodun görünmesini sağlar. */
    suspend fun start(host: String) = withContext(Dispatchers.IO) {
        val s = Certs.connect(identity, host, 6467, 20000)
        socket = s
        input = s.inputStream
        output = s.outputStream
        serverCert = s.session.peerCertificates[0] as X509Certificate

        send(msg(10) {
            string(1, "atvremote")
            string(2, "DETVI")
        })
        val ack = readOk()
        serverName = ack.field(11)?.sub()?.field(1)?.string() ?: ""

        send(msg(20) {
            message(1) { int(1, 3); int(2, 6) } // HEXADECIMAL, 6 hane
            int(3, 1)                           // rol: INPUT
        })
        readOk()

        send(msg(30) {
            message(1) { int(1, 3); int(2, 6) }
            int(2, 1)
        })
        readOk()
    }

    /** Kullanıcının girdiği 6 haneli kodu doğrular. */
    suspend fun finish(code: String) = withContext(Dispatchers.IO) {
        val clean = code.trim().uppercase()
        if (clean.length != 6 || !clean.all { it in '0'..'9' || it in 'A'..'F' }) {
            throw IOException("Kod 6 haneli olmalı (0-9, A-F)")
        }
        val clientKey = identity.cert.publicKey as RSAPublicKey
        val serverKey = serverCert!!.publicKey as RSAPublicKey

        val sha = MessageDigest.getInstance("SHA-256")
        sha.update(unsigned(clientKey.modulus.toByteArray()))
        sha.update(unsigned(clientKey.publicExponent.toByteArray()))
        sha.update(unsigned(serverKey.modulus.toByteArray()))
        sha.update(unsigned(serverKey.publicExponent.toByteArray()))
        sha.update(hexToBytes(clean.substring(2)))
        val hash = sha.digest()

        val expected = clean.substring(0, 2).toInt(16)
        if ((hash[0].toInt() and 0xFF) != expected) {
            throw IOException("Kod yanlış. TV ekranındaki kodu tekrar kontrol et.")
        }

        send(msg(40) { bytes(1, hash) })
        readOk()
        close()
    }

    fun close() {
        try { socket?.close() } catch (e: Exception) {}
        socket = null
    }

    private fun unsigned(b: ByteArray): ByteArray =
        if (b.size > 1 && b[0] == 0.toByte()) b.copyOfRange(1, b.size) else b

    private fun hexToBytes(s: String): ByteArray =
        ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}
