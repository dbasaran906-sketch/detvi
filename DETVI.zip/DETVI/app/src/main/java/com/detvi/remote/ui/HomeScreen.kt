package com.detvi.remote.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.detvi.remote.AppViewModel
import com.detvi.remote.R
import com.detvi.remote.data.SavedTv
import com.detvi.remote.tv.FoundTv

@Composable
fun HomeScreen(vm: AppViewModel) {
    val saved by vm.saved.collectAsState()
    val found by vm.found.collectAsState()
    val scanning by vm.scanning.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<SavedTv?>(null) }

    val spin by rememberInfiniteTransition(label = "spin").animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "spinAngle",
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Dv.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Üst bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 10.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(
                painterResource(R.drawable.detvi_logo),
                contentDescription = "DETVI",
                modifier = Modifier.height(42.dp),
                contentScale = ContentScale.Fit,
            )
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.deepScan() }) {
                Icon(
                    Icons.Rounded.Refresh,
                    contentDescription = "Yeniden tara",
                    tint = Dv.White,
                    modifier = Modifier.rotate(if (scanning) spin else 0f),
                )
            }
            IconButton(onClick = { showAdd = true }) {
                Icon(Icons.Rounded.Add, contentDescription = "IP ile ekle", tint = Dv.White)
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Brush.horizontalGradient(listOf(Dv.Red, Dv.Green, Dv.White.copy(alpha = 0.15f), Color.Transparent)))
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("Kumanda", color = Dv.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Wifi, null, tint = Dv.Green, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Bağlı olduğun Wi-Fi'deki Android TV ve Google TV'ler",
                        color = Dv.Muted,
                        fontSize = 13.sp,
                    )
                }
                Spacer(Modifier.height(10.dp))
            }

            item { SectionLabel("BU AĞDA") }
            if (found.isEmpty()) {
                item { ScanCard(scanning) }
            } else {
                items(found, key = { "f_" + it.host }) { tv ->
                    val isSaved = saved.any { it.host == tv.host || it.name == tv.name }
                    TvCard(
                        title = tv.name,
                        subtitle = tv.host,
                        badge = if (isSaved) "KAYITLI" else "YENİ",
                        online = true,
                        onClick = { vm.onFoundTapped(tv) },
                    )
                }
            }

            item { Spacer(Modifier.height(8.dp)); SectionLabel("KAYITLI TV'LER") }
            if (saved.isEmpty()) {
                item {
                    Text(
                        "Henüz TV yok. Bir TV'ye bağlandığında burada saklanır; bir daha eşleştirmen gerekmez.",
                        color = Dv.Muted,
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                    )
                }
            } else {
                items(saved, key = { "s_" + it.host }) { tv ->
                    val online = found.any { it.host == tv.host || it.name == tv.name }
                    TvCard(
                        title = tv.name,
                        subtitle = tv.host + "  ·  " + ago(tv.lastUsed),
                        badge = null,
                        online = online,
                        onClick = { vm.connect(tv) },
                        onRemove = { toDelete = tv },
                    )
                }
            }
        }
    }

    if (showAdd) {
        AddIpDialog(
            onAdd = { ip -> showAdd = false; vm.addManual(ip) },
            onClose = { showAdd = false },
        )
    }
    toDelete?.let { tv ->
        ConfirmDialog(
            title = "TV silinsin mi?",
            text = "\"${tv.name}\" kayıtlı listenden kalkar. Tekrar bağlanmak için yeniden eşleştirmen gerekebilir.",
            confirm = "Sil",
            onConfirm = { vm.removeSaved(tv); toDelete = null },
            onClose = { toDelete = null },
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Dv.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
}

@Composable
private fun TvCard(
    title: String,
    subtitle: String,
    badge: String?,
    online: Boolean,
    onClick: () -> Unit,
    onRemove: (() -> Unit)? = null,
) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Dv.CardHi, Dv.Card)))
            .border(1.dp, Dv.Line, shape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Dv.Red, Dv.RedDeep))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Tv, null, tint = Dv.White, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (online) Dv.Green else Dv.Line)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    title,
                    color = Dv.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                )
            }
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Dv.Muted, fontSize = 12.sp, maxLines = 1)
        }
        if (badge != null) {
            Text(
                badge,
                color = if (badge == "YENİ") Dv.Green else Dv.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .border(1.dp, if (badge == "YENİ") Dv.Green else Dv.Line, RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
            )
            Spacer(Modifier.width(6.dp))
        }
        if (onRemove != null) {
            IconButton(onClick = onRemove, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Rounded.Close, "Sil", tint = Dv.Muted, modifier = Modifier.size(18.dp))
            }
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = Dv.Muted)
    }
}

@Composable
private fun ScanCard(scanning: Boolean) {
    val shape = RoundedCornerShape(24.dp)
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseAlpha",
    )
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Dv.Card)
            .border(1.dp, Dv.Line, shape)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(14.dp)
                .alpha(if (scanning) pulse else 1f)
                .clip(CircleShape)
                .background(if (scanning) Dv.Red else Dv.Muted)
        )
        Spacer(Modifier.width(14.dp))
        Column {
            Text(
                if (scanning) "TV'ler aranıyor…" else "TV bulunamadı",
                color = Dv.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
            )
            if (!scanning) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "TV'nin açık ve telefonla aynı Wi-Fi'de olduğundan emin ol. Sağ üstteki yenile tuşuyla tekrar tara ya da + ile IP gir.",
                    color = Dv.Muted,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                )
            }
        }
    }
}

private fun ago(ms: Long): String {
    if (ms <= 0L) return "yeni"
    val min = (System.currentTimeMillis() - ms) / 60_000L
    return when {
        min < 1 -> "az önce"
        min < 60 -> "$min dk önce"
        min < 60 * 24 -> "${min / 60} sa önce"
        else -> "${min / (60 * 24)} gün önce"
    }
}
