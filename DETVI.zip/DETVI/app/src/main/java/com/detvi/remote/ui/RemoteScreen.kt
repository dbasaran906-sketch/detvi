package com.detvi.remote.ui

import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SettingsInputHdmi
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.detvi.remote.AppViewModel
import com.detvi.remote.tv.AppLinks
import com.detvi.remote.tv.Keys
import com.detvi.remote.tv.LinkStatus
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sign

@Composable
fun RemoteScreen(vm: AppViewModel) {
    val link by vm.link.collectAsState()
    val tv by vm.current.collectAsState()
    val ctx = LocalContext.current
    val view = LocalView.current
    val fb = remember { Feedback(ctx, view) }

    var tab by remember { mutableIntStateOf(0) }
    var flash by remember { mutableIntStateOf(0) }
    var ledOn by remember { mutableStateOf(false) }
    var showKeyboard by remember { mutableStateOf(false) }
    var voiceText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(flash) {
        if (flash > 0) {
            ledOn = true
            delay(130)
            ledOn = false
        }
    }

    val send: (Int) -> Unit = { code ->
        fb.click()
        flash++
        vm.key(code)
    }
    val open: (String) -> Unit = { l ->
        fb.click()
        flash++
        vm.openLink(l)
    }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) voiceText = t
    }
    val startVoice: () -> Unit = {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Ne arayalım?")
            }
            voiceLauncher.launch(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Sesli komut bu telefonda desteklenmiyor", Toast.LENGTH_SHORT).show()
        }
    }
    val startCast: () -> Unit = {
        try {
            ctx.startActivity(Intent("android.settings.CAST_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
                Toast.makeText(ctx, "Ekran paylaşımı ayarı açılamadı", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Dv.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar(
                name = tv?.name ?: "TV",
                ready = link.status == LinkStatus.Ready,
                connecting = link.status == LinkStatus.Connecting,
                volume = link.volume,
                muted = link.muted,
                onBack = { vm.leaveRemote() },
                onKeyboard = { showKeyboard = true },
                onMic = startVoice,
                onCast = startCast,
            )
            Tabs(tab) { tab = it }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> RemoteBody(ledOn, send, startVoice)
                    1 -> TouchpadTab(send)
                    else -> AppsTab(
                        send = send,
                        open = open,
                        onKeyboard = { showKeyboard = true },
                        onMic = startVoice,
                        onCast = startCast,
                    )
                }
            }
        }

        if (link.status != LinkStatus.Ready) {
            StatusOverlay(
                connecting = link.status == LinkStatus.Connecting || link.status == LinkStatus.Idle,
                message = link.message,
                neverReady = link.neverReady,
                onRetry = { vm.reconnect() },
                onRePair = { vm.rePair() },
                onBack = { vm.leaveRemote() },
            )
        }
    }

    if (showKeyboard) {
        KeyboardDialog(
            onType = { vm.typeText(it) },
            onKey = { vm.key(it) },
            onClose = { showKeyboard = false },
        )
    }
    voiceText?.let { t ->
        VoiceDialog(
            text = t,
            onTv = { vm.typeText(t); voiceText = null },
            onYoutube = { vm.openLink(AppLinks.youtubeSearch(t)); voiceText = null },
            onClose = { voiceText = null },
        )
    }
}

// ---------------------------------------------------------------- üst bar

@Composable
private fun TopBar(
    name: String,
    ready: Boolean,
    connecting: Boolean,
    volume: Int,
    muted: Boolean,
    onBack: () -> Unit,
    onKeyboard: () -> Unit,
    onMic: () -> Unit,
    onCast: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(start = 6.dp, end = 6.dp, top = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Geri", tint = Dv.White)
        }
        Column(Modifier.weight(1f)) {
            Text(name, color = Dv.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(if (ready) Dv.Green else if (connecting) Dv.Yellow else Dv.Red)
                )
                Spacer(Modifier.width(6.dp))
                val status = when {
                    ready && volume >= 0 -> if (muted) "Bağlı · Sessiz" else "Bağlı · Ses $volume"
                    ready -> "Bağlı"
                    connecting -> "Bağlanıyor…"
                    else -> "Bağlı değil"
                }
                Text(status, color = Dv.Muted, fontSize = 12.sp)
            }
        }
        IconButton(onClick = onKeyboard) { Icon(Icons.Rounded.Keyboard, "Klavye", tint = Dv.White) }
        IconButton(onClick = onMic) { Icon(Icons.Rounded.Mic, "Sesli komut", tint = Dv.White) }
        IconButton(onClick = onCast) { Icon(Icons.Rounded.Cast, "Ekran paylaş", tint = Dv.White) }
    }
}

@Composable
private fun Tabs(selected: Int, onSelect: (Int) -> Unit) {
    val labels = listOf("KUMANDA", "TOUCHPAD", "UYGULAMALAR")
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .clip(shape)
            .background(Dv.Card)
            .border(1.dp, Dv.Line, shape)
            .padding(4.dp),
    ) {
        labels.forEachIndexed { i, label ->
            Box(
                Modifier
                    .weight(1f)
                    .clip(shape)
                    .background(if (i == selected) Dv.Red else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (i == selected) Dv.White else Dv.Muted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- kumanda gövdesi

@Composable
private fun RemoteBody(ledOn: Boolean, send: (Int) -> Unit, onMic: () -> Unit) {
    val bodyShape = RoundedCornerShape(48.dp)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 10.dp),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(bodyShape)
                .background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFE4E4E8), Color(0xFFCFCFD5))))
                .border(
                    1.5.dp,
                    Brush.verticalGradient(listOf(Color.White, Color(0xFF8E8E96))),
                    bodyShape,
                )
                .padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // LED + marka
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (ledOn) Dv.Green else Color(0xFFB4B4BB))
                )
                Text("DETVI", color = Color(0xFF8A8A92), fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
                Box(Modifier.size(10.dp))
            }
            Spacer(Modifier.height(14.dp))

            // Güç / Kaynak / Mikrofon
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                RoundKey(60.dp, Faces.Red, Dv.RedDeep, onPress = { send(Keys.POWER) }) {
                    Icon(Icons.Rounded.PowerSettingsNew, "Aç / Kapat", tint = Color.White, modifier = Modifier.size(28.dp))
                }
                RoundKey(52.dp, Faces.Black, Color.Black, onPress = { send(Keys.INPUT) }) {
                    Icon(Icons.Rounded.SettingsInputHdmi, "Kaynak", tint = Color.White, modifier = Modifier.size(24.dp))
                }
                RoundKey(52.dp, Faces.Black, Color.Black, onPress = onMic) {
                    Icon(Icons.Rounded.Mic, "Sesli komut", tint = Color.White, modifier = Modifier.size(24.dp))
                }
            }
            Spacer(Modifier.height(18.dp))

            // Yön halkası
            DPad(send)
            Spacer(Modifier.height(16.dp))

            // Geri / Ana ekran / Menü
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                RoundKey(58.dp, Faces.Black, Color.Black, onPress = { send(Keys.BACK) }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Geri", tint = Color.White, modifier = Modifier.size(26.dp))
                }
                RoundKey(58.dp, Faces.Black, Color.Black, onPress = { send(Keys.HOME) }) {
                    Icon(Icons.Rounded.Home, "Ana ekran", tint = Color.White, modifier = Modifier.size(26.dp))
                }
                RoundKey(58.dp, Faces.Black, Color.Black, onPress = { send(Keys.MENU) }) {
                    Icon(Icons.Rounded.Menu, "Menü", tint = Color.White, modifier = Modifier.size(26.dp))
                }
            }
            Spacer(Modifier.height(16.dp))

            // Ses / orta / Kanal
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Rocker("SES", Icons.Rounded.Add, Icons.Rounded.Remove, { send(Keys.VOL_UP) }, { send(Keys.VOL_DOWN) })
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    RoundKey(54.dp, Faces.Black, Color.Black, onPress = { send(Keys.MUTE) }) {
                        Icon(Icons.Rounded.VolumeOff, "Sessiz", tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    RoundKey(54.dp, Faces.Black, Color.Black, onPress = { send(Keys.SETTINGS) }) {
                        Icon(Icons.Rounded.Settings, "Ayarlar", tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
                Rocker("KANAL", Icons.Rounded.KeyboardArrowUp, Icons.Rounded.KeyboardArrowDown, { send(Keys.CH_UP) }, { send(Keys.CH_DOWN) })
            }
            Spacer(Modifier.height(14.dp))

            // Medya
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                MediaKey(Icons.Rounded.FastRewind, "Geri sar") { send(Keys.REWIND) }
                MediaKey(Icons.Rounded.PlayArrow, "Oynat / Duraklat") { send(Keys.PLAY_PAUSE) }
                MediaKey(Icons.Rounded.FastForward, "İleri sar") { send(Keys.FFWD) }
            }
            Spacer(Modifier.height(6.dp))
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun DPad(send: (Int) -> Unit) {
    val arrowFace = Brush.verticalGradient(listOf(Color(0xFF2C2C32), Color(0xFF15151A)))
    val key = RoundedCornerShape(18.dp)
    Box(Modifier.size(248.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .matchParentSize()
                .shadow(10.dp, CircleShape, clip = false)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color(0xFF303036), Color(0xFF050506))))
                .border(1.dp, Color(0xFF45454C), CircleShape)
        )
        Box(
            Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color(0xFF0B0B0D), Color(0xFF1C1C21))))
        )
        KeyButton(60.dp, 44.dp, key, arrowFace, Color.Black, Modifier.align(Alignment.TopCenter).padding(top = 12.dp), repeat = true, depth = 4.dp, onPress = { send(Keys.UP) }) {
            Icon(Icons.Rounded.KeyboardArrowUp, "Yukarı", tint = Color.White, modifier = Modifier.size(34.dp))
        }
        KeyButton(60.dp, 44.dp, key, arrowFace, Color.Black, Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp), repeat = true, depth = 4.dp, onPress = { send(Keys.DOWN) }) {
            Icon(Icons.Rounded.KeyboardArrowDown, "Aşağı", tint = Color.White, modifier = Modifier.size(34.dp))
        }
        KeyButton(44.dp, 60.dp, key, arrowFace, Color.Black, Modifier.align(Alignment.CenterStart).padding(start = 12.dp), repeat = true, depth = 4.dp, onPress = { send(Keys.LEFT) }) {
            Icon(Icons.Rounded.KeyboardArrowLeft, "Sol", tint = Color.White, modifier = Modifier.size(34.dp))
        }
        KeyButton(44.dp, 60.dp, key, arrowFace, Color.Black, Modifier.align(Alignment.CenterEnd).padding(end = 12.dp), repeat = true, depth = 4.dp, onPress = { send(Keys.RIGHT) }) {
            Icon(Icons.Rounded.KeyboardArrowRight, "Sağ", tint = Color.White, modifier = Modifier.size(34.dp))
        }
        RoundKey(88.dp, Faces.White, Color(0xFF8F8F97), onPress = { send(Keys.OK) }) {
            Text("OK", color = Color(0xFF111114), fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Rocker(
    label: String,
    upIcon: ImageVector,
    downIcon: ImageVector,
    onUp: () -> Unit,
    onDown: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        KeyButton(
            72.dp, 62.dp,
            RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp, bottomStart = 12.dp, bottomEnd = 12.dp),
            Faces.Black, Color.Black, repeat = true, onPress = onUp,
        ) {
            Icon(upIcon, "$label +", tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Text(label, color = Color(0xFF7C7C84), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 6.dp))
        KeyButton(
            72.dp, 62.dp,
            RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomStart = 36.dp, bottomEnd = 36.dp),
            Faces.Black, Color.Black, repeat = true, onPress = onDown,
        ) {
            Icon(downIcon, "$label -", tint = Color.White, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
private fun MediaKey(icon: ImageVector, desc: String, onPress: () -> Unit) {
    KeyButton(76.dp, 46.dp, pill(46.dp), Faces.Black, Color.Black, onPress = onPress) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.size(26.dp))
    }
}

// ---------------------------------------------------------------- touchpad

@Composable
private fun TouchpadTab(send: (Int) -> Unit) {
    val shape = RoundedCornerShape(34.dp)
    val sendNow by rememberUpdatedState(send)
    var glow by remember { mutableStateOf<Offset?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 10.dp)) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Dv.CardHi, Dv.Card)))
                .border(1.dp, Dv.Line, shape)
                .drawBehind {
                    glow?.let { c ->
                        val r = 130.dp.toPx()
                        drawCircle(
                            brush = Brush.radialGradient(listOf(Dv.Red.copy(alpha = 0.55f), Color.Transparent), center = c, radius = r),
                            radius = r,
                            center = c,
                        )
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { sendNow(Keys.OK) },
                        onLongPress = { sendNow(Keys.BACK) },
                    )
                }
                .pointerInput(Unit) {
                    var ax = 0f
                    var ay = 0f
                    val step = 64.dp.toPx()
                    detectDragGestures(
                        onDragStart = { o -> ax = 0f; ay = 0f; glow = o },
                        onDragEnd = { glow = null },
                        onDragCancel = { glow = null },
                    ) { change, d ->
                        change.consume()
                        glow = change.position
                        ax += d.x
                        ay += d.y
                        while (abs(ax) >= step || abs(ay) >= step) {
                            if (abs(ax) >= abs(ay)) {
                                sendNow(if (ax > 0) Keys.RIGHT else Keys.LEFT)
                                ax -= step * sign(ax)
                            } else {
                                sendNow(if (ay > 0) Keys.DOWN else Keys.UP)
                                ay -= step * sign(ay)
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Kaydır", color = Dv.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Dokun = Tamam  ·  Basılı tut = Geri",
                    color = Dv.Muted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            RoundKey(54.dp, Faces.Dark, Color.Black, onPress = { send(Keys.BACK) }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Geri", tint = Color.White, modifier = Modifier.size(24.dp))
            }
            RoundKey(54.dp, Faces.Dark, Color.Black, onPress = { send(Keys.HOME) }) {
                Icon(Icons.Rounded.Home, "Ana ekran", tint = Color.White, modifier = Modifier.size(24.dp))
            }
            RoundKey(54.dp, Faces.Dark, Color.Black, repeat = true, onPress = { send(Keys.VOL_DOWN) }) {
                Icon(Icons.Rounded.Remove, "Sesi kıs", tint = Color.White, modifier = Modifier.size(24.dp))
            }
            RoundKey(54.dp, Faces.Dark, Color.Black, onPress = { send(Keys.MUTE) }) {
                Icon(Icons.Rounded.VolumeOff, "Sessiz", tint = Color.White, modifier = Modifier.size(24.dp))
            }
            RoundKey(54.dp, Faces.Dark, Color.Black, repeat = true, onPress = { send(Keys.VOL_UP) }) {
                Icon(Icons.Rounded.Add, "Sesi aç", tint = Color.White, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ---------------------------------------------------------------- uygulamalar & araçlar

@Composable
private fun AppsTab(
    send: (Int) -> Unit,
    open: (String) -> Unit,
    onKeyboard: () -> Unit,
    onMic: () -> Unit,
    onCast: () -> Unit,
) {
    val tileW: Dp = ((LocalConfiguration.current.screenWidthDp - 40 - 14) / 2).dp
    val tileH = 92.dp
    val shape = RoundedCornerShape(26.dp)

    @Composable
    fun AppTile(label: String, letter: String, face: Brush, base: Color, onPress: () -> Unit) {
        KeyButton(tileW, tileH, shape, face, base, onPress = onPress) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(letter, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    fun ToolTile(label: String, icon: ImageVector, onPress: () -> Unit) {
        KeyButton(tileW, 76.dp, shape, Faces.Dark, Color.Black, onPress = onPress) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, label, tint = Color.White, modifier = Modifier.size(26.dp))
                Spacer(Modifier.height(4.dp))
                Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    val blue = Brush.verticalGradient(listOf(Color(0xFF4C84FF), Color(0xFF1B4FD8)))
    val deepBlue = Brush.verticalGradient(listOf(Color(0xFF2A55C9), Color(0xFF14307A)))
    val dark = Brush.verticalGradient(listOf(Color(0xFF2A2A2F), Color(0xFF0C0C0E)))
    val purple = Brush.verticalGradient(listOf(Color(0xFFA06BFF), Color(0xFF5A2CC2)))

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("UYGULAMALAR", color = Dv.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AppTile("YouTube", "▶", Faces.Red, Dv.RedDeep) { open(AppLinks.YOUTUBE) }
            AppTile("Netflix", "N", dark, Color.Black) { open(AppLinks.NETFLIX) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AppTile("Prime Video", "P", blue, Color(0xFF0F2E86)) { open(AppLinks.PRIME) }
            AppTile("Disney+", "D", deepBlue, Color(0xFF0A1B4A)) { open(AppLinks.DISNEY) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AppTile("Spotify", "S", Faces.Green, Color(0xFF086B31)) { open(AppLinks.SPOTIFY) }
            AppTile("Twitch", "T", purple, Color(0xFF31167A)) { open(AppLinks.TWITCH) }
        }
        Spacer(Modifier.height(6.dp))
        Text("ARAÇLAR", color = Dv.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            ToolTile("Ekran Paylaş", Icons.Rounded.Cast, onCast)
            ToolTile("Sesli Komut", Icons.Rounded.Mic, onMic)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            ToolTile("Klavye", Icons.Rounded.Keyboard, onKeyboard)
            ToolTile("TV Ayarları", Icons.Rounded.Settings) { send(Keys.SETTINGS) }
        }
        Text(
            "Uygulama kısayolları, TV'de ilgili uygulama yüklüyse çalışır.",
            color = Dv.Muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
        )
    }
}

// ---------------------------------------------------------------- bağlantı durumu

@Composable
private fun StatusOverlay(
    connecting: Boolean,
    message: String,
    neverReady: Boolean,
    onRetry: () -> Unit,
    onRePair: () -> Unit,
    onBack: () -> Unit,
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.82f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(28.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Dv.Card)
                .border(1.dp, Dv.Line, RoundedCornerShape(28.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (connecting) {
                CircularProgressIndicator(color = Dv.Red, strokeWidth = 3.dp, modifier = Modifier.size(36.dp))
                Spacer(Modifier.height(14.dp))
                Text("TV'ye bağlanılıyor…", color = Dv.White, fontWeight = FontWeight.Bold)
            } else {
                Text(message.ifBlank { "Bağlantı kurulamadı" }, color = Dv.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (neverReady) "TV kapalı olabilir ya da eşleşme silinmiş olabilir." else "TV'nin açık ve aynı Wi-Fi'de olduğundan emin ol.",
                    color = Dv.Muted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onRetry) { Text("Tekrar dene", color = Dv.Green, fontWeight = FontWeight.Bold) }
                    if (neverReady) {
                        TextButton(onClick = onRePair) { Text("Yeniden eşleştir", color = Dv.Red, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            TextButton(onClick = onBack) { Text("Listeye dön", color = Dv.Muted) }
        }
    }
}
