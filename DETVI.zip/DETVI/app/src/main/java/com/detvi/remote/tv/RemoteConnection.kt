package com.detvi.remote.tv

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.URLEncoder
import javax.net.ssl.SSLSocket

enum class LinkStatus { Idle, Connecting, Ready, Failed }

data class LinkState(
    val status: LinkStatus = LinkStatus.Idle,
    val message: String = "",
    /** Bağlantı hiç hazır olmadan koptuysa büyük ihtimalle eşleşme yok/silinmiş demektir. */
    val neverReady: Boolean = false,
    val volume: Int = -1,
    val volumeMax: Int = 100,
    val muted: Boolean = false,
)

object Keys {
    const val UP = 19
    const val DOWN = 20
    const val LEFT = 21
    const val RIGHT = 22
    const val OK = 23
    const val BACK = 4
    const val HOME = 3
    const val MENU = 82
    const val POWER = 26
    const val VOL_UP = 24
    const val VOL_DOWN = 25
    const val MUTE = 164
    const val PLAY_PAUSE = 85
    const val NEXT = 87
    const val PREV = 88
    const val REWIND = 89
    const val FFWD = 90
    const val CH_UP = 166
    const val CH_DOWN = 167
    const val INPUT = 178
    const val SETTINGS = 176
    const val GUIDE = 172
    const val INFO = 165
    const val DEL = 67
    const val ENTER = 66
    const val SPACE = 62

    /** Yazılan karakteri Android tuş koduna çevirir (Türkçe harfler sadeleştirilir). */
    fun forChar(ch: Char): Int? {
        val c = when (ch) {
            'ç', 'Ç' -> 'c'
            'ğ', 'Ğ' -> 'g'
            'ı', 'İ', 'I' -> 'i'
            'ö', 'Ö' -> 'o'
            'ş', 'Ş' -> 's'
            'ü', 'Ü' -> 'u'
            else -> ch.lowercaseChar()
        }
        return when (c) {
            in 'a'..'z' -> 29 + (c - 'a')
            in '0'..'9' -> 7 + (c - '0')
            ' ' -> SPACE
            '\n' -> ENTER
            '.' -> 56
            ',' -> 55
            '-' -> 69
            '@' -> 77
            else -> null
        }
    }
}

object AppLinks {
    const val YOUTUBE = "https://www.youtube.com"
    const val NETFLIX = "https://www.netflix.com"
    const val PRIME = "https://www.primevideo.com"
    const val DISNEY = "https://www.disneyplus.com"
    const val SPOTIFY = "https://open.spotify.com"
    const val TWITCH = "https://www.twitch.tv"

    fun youtubeSearch(query: String): String =
        "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8")
}

/**
 * Android TV Remote v2 (port 6466). Tuşlar sıraya konup tek bir yazıcı coroutine ile gönderilir.
 */
class RemoteConnection(
    private val identity: Certs.Identity,
    private val scope: CoroutineScope,
) {
    val state = MutableStateFlow(LinkState())

    private var socket: SSLSocket? = null
    private var outbox = Channel<ByteArray>(Channel.UNLIMITED)
    private var job: Job? = null
    @Volatile private var intentional = false

    fun connect(host: String) {
        disconnect()
        intentional = false
        state.value = LinkState(LinkStatus.Connecting)
        val box = Channel<ByteArray>(Channel.UNLIMITED)
        outbox = box

        job = scope.launch(Dispatchers.IO) {
            var ready = false
            try {
                val s = Certs.connect(identity, host, 6466, 30000)
                socket = s
                val input = s.inputStream
                val output = s.outputStream

                launch {
                    try {
                        for (m in box) Proto.writeFrame(output, m)
                    } catch (e: Exception) {
                        try { s.close() } catch (ignored: Exception) {}
                    }
                }

                while (isActive) {
                    val frame = Proto.readFrame(input) ?: break
                    val f = Proto.parse(frame)

                    if (f.field(1) != null) { // TV yapılandırma istedi
                        box.trySend(
                            ProtoWriter().message(1) {
                                int(1, 622)
                                message(2) {
                                    string(1, "DETVI")
                                    string(2, "DETVI")
                                    int(3, 1)
                                    string(4, "1")
                                    string(5, "com.detvi.remote")
                                    string(6, "1.0.0")
                                }
                            }.toByteArray()
                        )
                    }
                    if (f.field(2) != null) { // set_active
                        box.trySend(ProtoWriter().message(2) { int(1, 622) }.toByteArray())
                        if (!ready) {
                            ready = true
                            state.value = state.value.copy(status = LinkStatus.Ready, message = "", neverReady = false)
                        }
                    }
                    val ping = f.field(8)
                    if (ping != null) {
                        val v = ping.sub().field(1)?.varint ?: 0L
                        box.trySend(ProtoWriter().message(9) { int(1, v.toInt()) }.toByteArray())
                    }
                    if (f.field(40) != null && !ready) {
                        ready = true
                        state.value = state.value.copy(status = LinkStatus.Ready, message = "", neverReady = false)
                    }
                    val vol = f.field(50)
                    if (vol != null) {
                        val v = vol.sub()
                        val max = v.field(6)?.varint?.toInt() ?: state.value.volumeMax
                        val lvl = v.field(7)?.varint?.toInt() ?: state.value.volume
                        val muted = (v.field(8)?.varint ?: 0L) != 0L
                        state.value = state.value.copy(volume = lvl, volumeMax = if (max > 0) max else 100, muted = muted)
                    }
                }
                if (!intentional) {
                    state.value = state.value.copy(
                        status = LinkStatus.Failed,
                        message = if (ready) "Bağlantı koptu" else "TV bağlantıyı reddetti",
                        neverReady = !ready,
                    )
                }
            } catch (e: Exception) {
                if (!intentional) {
                    state.value = state.value.copy(
                        status = LinkStatus.Failed,
                        message = if (ready) "Bağlantı koptu" else "TV'ye ulaşılamadı",
                        neverReady = !ready,
                    )
                }
            } finally {
                try { socket?.close() } catch (ignored: Exception) {}
            }
        }
    }

    fun disconnect() {
        intentional = true
        job?.cancel()
        job = null
        outbox.close()
        try { socket?.close() } catch (e: Exception) {}
        socket = null
        state.value = LinkState()
    }

    /** direction: 3 = kısa basış */
    fun key(code: Int, direction: Int = 3) {
        outbox.trySend(ProtoWriter().message(10) { int(1, code); int(2, direction) }.toByteArray())
    }

    fun openLink(link: String) {
        outbox.trySend(ProtoWriter().message(90) { string(1, link) }.toByteArray())
    }

    fun typeText(text: String) {
        for (ch in text) {
            val code = Keys.forChar(ch) ?: continue
            key(code)
        }
    }

    companion object {
        /** Widget için: bağlan, tuşu gönder, kapat. */
        suspend fun oneShot(identity: Certs.Identity, host: String, keyCode: Int): Boolean =
            withContext(Dispatchers.IO) {
                val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
                val c = RemoteConnection(identity, s)
                c.connect(host)
                val st = withTimeoutOrNull(7000) {
                    c.state.first { it.status == LinkStatus.Ready || it.status == LinkStatus.Failed }
                }
                val ok = st?.status == LinkStatus.Ready
                if (ok) {
                    c.key(keyCode)
                    delay(300)
                }
                c.disconnect()
                s.cancel()
                ok
            }
    }
}
