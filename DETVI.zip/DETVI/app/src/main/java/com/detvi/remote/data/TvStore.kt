package com.detvi.remote.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedTv(val name: String, val host: String, val lastUsed: Long)

/** Daha önce kontrol edilen TV'leri telefonda saklar. */
class TvStore(context: Context) {
    private val prefs = context.getSharedPreferences("detvi_tvs", Context.MODE_PRIVATE)

    fun load(): List<SavedTv> {
        val out = ArrayList<SavedTv>()
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(SavedTv(o.getString("name"), o.getString("host"), o.optLong("last", 0L)))
            }
        } catch (e: Exception) {
            // boş liste
        }
        return out.sortedByDescending { it.lastUsed }
    }

    private fun write(list: List<SavedTv>) {
        val arr = JSONArray()
        for (t in list) {
            arr.put(JSONObject().put("name", t.name).put("host", t.host).put("last", t.lastUsed))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun upsert(tv: SavedTv): List<SavedTv> {
        val list = load().filter { it.host != tv.host }.toMutableList()
        list.add(tv)
        write(list)
        prefs.edit().putString("last_host", tv.host).apply()
        return load()
    }

    fun touch(host: String): List<SavedTv> {
        val list = load().map { if (it.host == host) it.copy(lastUsed = System.currentTimeMillis()) else it }
        write(list)
        prefs.edit().putString("last_host", host).apply()
        return load()
    }

    fun updateHost(name: String, newHost: String): List<SavedTv> {
        val list = load().map { if (it.name == name) it.copy(host = newHost) else it }
        write(list)
        return load()
    }

    fun remove(host: String): List<SavedTv> {
        write(load().filter { it.host != host })
        return load()
    }

    fun lastTv(): SavedTv? {
        val h = prefs.getString("last_host", null)
        val all = load()
        return all.firstOrNull { it.host == h } ?: all.firstOrNull()
    }
}
