package com.detvi.remote.ui

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.SoundEffectConstants
import android.view.View
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Tuşa basınca kısa titreşim + tık sesi. */
class Feedback(context: Context, private val view: View) {
    private val vibrator: Vibrator? = findVibrator(context)

    @Suppress("DEPRECATION")
    private fun findVibrator(context: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    fun click() {
        try {
            vibrator?.vibrate(VibrationEffect.createOneShot(16, 170))
            view.playSoundEffect(SoundEffectConstants.CLICK)
        } catch (e: Exception) {
            // titreşim yoksa sessizce geç
        }
    }
}

object Faces {
    val Black = Brush.verticalGradient(listOf(Color(0xFF34343A), Color(0xFF0F0F11)))
    val BlackSoft = Brush.verticalGradient(listOf(Color(0xFF26262B), Color(0xFF111114)))
    val White = Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFD9D9DE)))
    val Red = Brush.verticalGradient(listOf(Color(0xFFFF5546), Color(0xFFD81F14)))
    val Green = Brush.verticalGradient(listOf(Color(0xFF2EE27D), Color(0xFF0E9F4B)))
    val Dark = Brush.verticalGradient(listOf(Color(0xFF232328), Color(0xFF131316)))
}

/**
 * Gerçek kumanda tuşu: basınca içeri çöker, gölgesi küçülür, alt kenarı kapanır.
 * w/h tuşun yüz boyutudur; kalınlık (depth) için altta ekstra yer ayrılır.
 */
@Composable
fun KeyButton(
    w: Dp,
    h: Dp,
    shape: Shape,
    face: Brush,
    base: Color,
    modifier: Modifier = Modifier,
    repeat: Boolean = false,
    depth: Dp = 5.dp,
    onPress: () -> Unit,
    content: @Composable BoxScope.(pressed: Boolean) -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    val sink by animateDpAsState(if (pressed) depth else 0.dp, tween(55), label = "sink")
    val scale by animateFloatAsState(if (pressed) 0.965f else 1f, tween(55), label = "scale")
    val current by rememberUpdatedState(onPress)
    val scope = rememberCoroutineScope()

    Box(
        modifier
            .size(w, h + depth)
            .pointerInput(repeat) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    current()
                    val job = if (repeat) {
                        scope.launch {
                            delay(420)
                            while (true) {
                                current()
                                delay(95)
                            }
                        }
                    } else null
                    waitForUpOrCancellation()
                    job?.cancel()
                    pressed = false
                }
            }
    ) {
        // Alt kenar (tuşun kalınlığı)
        Box(
            Modifier
                .size(w, h)
                .offset(y = depth)
                .clip(shape)
                .background(base)
        )
        // Tuş yüzü
        Box(
            Modifier
                .size(w, h)
                .offset(y = sink)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .shadow(if (pressed) 1.dp else 7.dp, shape, clip = false)
                .clip(shape)
                .background(face),
            contentAlignment = Alignment.Center,
        ) {
            content(pressed)
            if (pressed) {
                Box(
                    Modifier
                        .matchParentSize()
                        .background(Color.Black.copy(alpha = 0.14f))
                )
            }
        }
    }
}

/** Yuvarlak tuş kısayolu */
@Composable
fun RoundKey(
    size: Dp,
    face: Brush,
    base: Color,
    modifier: Modifier = Modifier,
    repeat: Boolean = false,
    onPress: () -> Unit,
    content: @Composable BoxScope.(pressed: Boolean) -> Unit,
) = KeyButton(size, size, CircleShape, face, base, modifier, repeat, 5.dp, onPress, content)

fun pill(h: Dp): Shape = RoundedCornerShape(h / 2)
